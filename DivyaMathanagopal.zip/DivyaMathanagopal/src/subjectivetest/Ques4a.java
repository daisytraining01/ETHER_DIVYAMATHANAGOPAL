package subjectivetest;

public class Ques4a {
	
	private String S;
	
	public String getS() {
		return S;
	}

	public void setS(String s) {
		S = s;
	}

	public Ques4a() {
		
		
		System.out.println("From Parent Class constructor" );
	}
	
}
