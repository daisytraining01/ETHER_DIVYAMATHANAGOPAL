package subjectivetest;

import java.lang.reflect.Method;

public class Ques8a {
	
	static void method1(int a, int b) {
		System.out.println(a+","+b);

	}
	static void method1(String a, String b) {
		System.out.println(a+","+b);
	}
	
	public static void main(String[] args) {
		method1(10,20);
		method1("ab","ba");
	}

}

/*OUTPUT
 
10,20
ab,ba
*/