package subjectivetest;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Ques1 {
	
	public static void main(String[] args) {
		
		Queue<Integer> li= new LinkedList<Integer>();
		for (int i = 10; i <= 50; i+=10) {
            li.add(i);
		}
		System.out.println("The list is " + li);
		System.out.println("The size of list is " + li.size());
		li.remove();
		System.out.println("The list is " + li);
		System.out.println("The size of list is " + li.size());
		
	}
	

}
/* We can clearly understand the FIFOconcept from the output
 * The list is [10, 20, 30, 40, 50]
The size of list is 5
The list is [20, 30, 40, 50]
The size of list is 4
*/

