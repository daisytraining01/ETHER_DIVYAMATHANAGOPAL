package subjectivetest;

public class Ques8c implements Ques8b{
	
	public static void main(String[] args) {
		 Ques8c obj= new Ques8c();
		 obj.axisBank();
		 obj.iciciBank();
	 
	}
	public void axisBank() {
		System.out.println("Axis BAnk");
		
	}

	
	public void iciciBank() {
		System.out.println("ICICI BAnk");
		
	}

}
/* After implementing the interface Ques8b,

Axis BAnk
ICICI BAnk
*/