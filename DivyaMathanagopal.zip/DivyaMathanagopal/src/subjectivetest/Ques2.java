package subjectivetest;

public class Ques2 {
	public static void main(String[] args) {
		
	
	
	int a=0,b=1,c;
	System.out.println("Fib series");
	System.out.println(a);
	System.out.println(b);
	for (int i = 0; i < 10; i++) {
		c=a+b;
		System.out.println(c);
		a=b;
		b=c;
		
	}
		
	}
}
/* OUTPUT
 * Fib series
0
1
1
2
3
5
8
13
21
34
55
89
*/
