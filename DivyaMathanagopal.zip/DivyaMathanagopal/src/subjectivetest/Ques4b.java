package subjectivetest;

public class Ques4b extends Ques4a{

	public static void main(String[] args) {
		
	
	Ques4a obj=new Ques4a();
	obj.setS("Ether");
	System.out.println(obj.getS());
	
}}
/*We infer that once the obj is created for the parent class, the constructor gets executed (constructor)
 *Getters setters methods used (encapsulation)
 *QUES4a has been inherited in Ques4b for execution (inheritance)
 From Parent Class constructor
Ether
*/
