package subjectivetest;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Ques7 {
	
	public static void main(String[] args) {
		 
		Map<String, String> m= new HashMap<String, String>();
		m.put("Key 1", "TestVal1");
		m.put("Key 2", "TestVal2");
		m.put("Key 3", "TestVal1");
		m.put("Key 4", "TestVal2");
		m.put("Key 5", "TestVal2");
		m.put("Key 6", "TestVal3");
		
	System.out.println(m);
	System.out.println("After removing Dups");
	Set<String> set=new HashSet<String>();
	Collection<String> mapValues = m.values();
	set.addAll(mapValues);
	System.out.println(set);
		
	}

}
/*The duplicates are removed using SET interface
 * {Key 1=TestVal1, Key 2=TestVal2, Key 3=TestVal1, Key 4=TestVal2, Key 5=TestVal2, Key 6=TestVal3}
After removing Dups
[TestVal1, TestVal2, TestVal3]
*/
