package subjectivetest;

import java.util.Scanner;

public class Ques6 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String str= sc.next();
		String rev="";
		for (int i = str.length()-1; i>=0; i--) {
			rev=rev+str.charAt(i);
		}
		if (str.equals(rev))
			System.out.println("The String is Palindrome");
		else
			System.out.println("The String is not Palindrome");
	}

}

/*OUTPUT
 * Enter the String
abba
The String is Palindrome
*/
