package subjectivetest;

public interface Ques8b {
	
	void axisBank();
	void iciciBank();

}

 

