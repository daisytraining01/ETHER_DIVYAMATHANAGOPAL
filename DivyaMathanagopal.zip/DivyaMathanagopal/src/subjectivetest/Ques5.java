package subjectivetest;

import java.util.Scanner;

public class Ques5 {
	
	public static void main(String[] args) {
		
		String str="REST ASSURED";
		String s1=str.replaceAll("ST","");
		System.out.println(s1);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Strings to comapare");
		System.out.println("Enter String 1");
		String s2= sc.next();
		System.out.println("Enter String 2");
		String s3= sc.next();
		if(s2.equals(s3))
			System.out.println("strings are the same");
		else
			System.out.println("strings arent the same");
		
	}

}
/*OUTPUT : RE ASSURED
Enter Strings to comapare
Enter String 1

Maveric
Enter String 2
Maveric
strings are the same*/
