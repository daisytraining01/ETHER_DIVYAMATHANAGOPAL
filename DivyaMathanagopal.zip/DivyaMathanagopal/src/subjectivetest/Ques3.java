package subjectivetest;
import java.io.*; 
public class Ques3 {
	    
	public static void main(String args[])  
	{  
	try  
	{  
	File file=new File(System.getProperty("user.dir")+"\\src\\subjectivetest\\Ques3.txt");
	FileReader fr=new FileReader(file);    
	BufferedReader br=new BufferedReader(fr);  
	StringBuffer sb=new StringBuffer();  
	String line;  
	while((line=br.readLine())!=null)  
	{  
	sb.append(line);      
	sb.append("\n");       
	}  
	fr.close();    
	System.out.println("The file contents: "); 
	System.out.println(sb.toString());    
	}  
	catch(IOException e)  
	{  
	e.printStackTrace();  
	}   
	}
	}
/*
 * The file contents: 
abcd
efgh
ijkl
mnop
qrst
uvwx
yzab
cdef
ghik
lmno
*/
 


